package Ejercicio1;
import java.io.IOException;

public class App {
	
	public static void main(String[] args) {
	
		ArchivosFicherosParam archivosFicheros = new ArchivosFicherosParam();
		try {
			archivosFicheros.leerFichero();
			archivosFicheros.ordenaLista();
			archivosFicheros.imprimeLista();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
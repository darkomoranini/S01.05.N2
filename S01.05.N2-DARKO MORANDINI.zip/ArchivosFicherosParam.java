package Ejercicio1;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class ArchivosFicherosParam {

	private ArrayList<String> lista1;
	private Properties properties;

	public ArchivosFicherosParam() {
		lista1 = new ArrayList<String>();
		properties = new Properties();
	}

	public ArrayList<String> getLista1() {
		return lista1;
	}

	public void leerFichero() throws IOException {
		try {
			loadProperties();
			
			String filePath = properties.getProperty("/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/config.properties");
			BufferedReader input = new BufferedReader(new FileReader(filePath));
			String line = input.readLine();

			while (line != null) {
				String[] parts = line.split(" ");
				lista1.add(parts[0]);
				lista1.add(parts[1]);
				line = input.readLine();
			}
			input.close();
		} catch (IOException e) {
			System.out.println("No se ha encontrado el archivo");
		}
	}
	
	public void leerFicheroArbol(BinarySearchTree<String> arbol, File fichero) throws IOException {
		try {
			loadProperties();
			
			String filePath = properties.getProperty("/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/config.properties");
			BufferedReader input = new BufferedReader(new FileReader(filePath));
			String line = input.readLine();

			while (line != null) {
				String[] parts = line.split(" ");
				arbol.add(parts[0] + "*" + fileType(fichero) + "*" + ultimaModificacion(fichero));
				arbol.add(parts[1] + "*" + fileType(fichero) + "*" + ultimaModificacion(fichero));
				line = input.readLine();
			}
			input.close();
		} catch (IOException e) {
			System.out.println("No se ha encontrado el archivo");
		}
	}

	private void loadProperties() throws IOException {
		String filePath = "/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/config.properties";
		try (InputStream input = new FileInputStream(filePath)) {
			properties.load(input);
		} catch (IOException e) {
			System.err.println("No se pudo cargar el archivo de propiedades.");
			throw e;
		}
	}
	
	public void ordenaLista() {
		Collections.sort(lista1); 
	}
	
	public void imprimeLista() {
		
		for (String nombre : lista1) {
            System.out.println(nombre);
		}
	}

	public String fileType(File fichero) {
		
		String tipoArchivo="";
		
		if(fichero.isFile()) {
			tipoArchivo="Archivo";
		}
		if(fichero.isDirectory()) {
			tipoArchivo="Directorio";
		}		
		
		return tipoArchivo;
	}
	
	public String ultimaModificacion(File fichero) {	
		
		long ultimaModificacion = fichero.lastModified();
	    Date fecha = new Date(ultimaModificacion);
	    SimpleDateFormat formato = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	    String formatoFecha = formato.format(fecha);
	        
	    return "Ultima modificacion: " + formatoFecha;
		
	}

	public void rellenaFichero(File fichero) throws IOException {
		
		try {
			FileWriter writer = new FileWriter(fichero);
			BufferedReader input=new BufferedReader(new FileReader("/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/Countries.txt"));
			String line = input.readLine();
			
			while(line.length()!=0) {
				
				String[] parts = line.split(" ");
				writer.write(parts[0]);
				writer.write(parts[1]);
				line=input.readLine();				
			}
		
			input.close();
			writer.close();
			
		} catch (IOException e) {
			System.out.println("No se ha encontrado el archivo");
		}
	}
}
